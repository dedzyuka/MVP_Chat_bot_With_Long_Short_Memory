# 🤖 AI Telegram Bot - Минимальный пакет

Этот пакет содержит все необходимое для запуска AI Telegram бота с памятью.

## 🚀 Быстрый запуск

### Linux/Mac:
```bash
chmod +x install.sh
./install.sh
```

### Windows:
```cmd
install.bat
```

## 📋 Что включено

- ✅ Готовый Docker образ `dedzyuka/chatbot:latest`
- ✅ Автоматическая установка PostgreSQL
- ✅ Веб-интерфейс pgAdmin
- ✅ Настройка переменных окружения

## 🔑 Что нужно настроить

Отредактируйте файл `.env` и укажите:
- `BOT_TOKEN` - токен от @BotFather
- `OPENAI_API_KEY` - ключ от OpenAI
- `GEMINI_EMBEDD` - ключ от Google AI

## 📚 Документация

- `QUICK_START.md` - быстрый старт за 5 минут
- `INSTALLATION_GUIDE.md` - подробная инструкция

## 🆘 Поддержка

Если возникли проблемы:
1. Проверьте логи: `docker logs chatbot`
2. Убедитесь в правильности API ключей
3. Перезапустите: `docker-compose restart`

---

**Готовый образ**: https://hub.docker.com/r/dedzyuka/chatbot
